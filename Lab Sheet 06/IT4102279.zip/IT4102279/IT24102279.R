# Q1: Hookworm treetment
# What distribushun is X?
# Its a binomyal with n=44 and p=0.92

# Chance of 40 kids cured?

dbinom(40, 44, 0.92)

# Chance of 35 or fewer cured?

pbinom(35, 44, 0.92, lower.tail = TRUE)

# Chance of 38 or more cured?

1 - pbinom(37, 44, 0.92, lower.tail = TRUE)

# Chance of 40 to 42 (includin both) cured?

dbinom(40, 44, 0.92) + dbinom(41, 44, 0.92) + dbinom(42, 44, 0.92)

# Q2: Baby births
# What is X?
# Number of babys born in a day

# What distrib is X?
# Its a Poisson with lambda=5

# Chance of 6 babys tomorrow?
# Use dpois for exact prob
dpois(6, 5)

# Chance of more than 6 babys?
# Use ppois with lower.tail=FALSE
1 - ppois(6, 5, lower.tail = TRUE)

# Q3: Learnin platform
# What distribushun is X?
# Binomyal with n=50 and p=0.85

# Chance of 47 or more passin?

1 - pbinom(46, 50, 0.85, lower.tail = TRUE)

# Q4: Call center
# What is X?
# Number of calls per hour

# What distribushun is X?
# Poisson with lambda=12

# Chance of exactly 15 calls?
# Use dpois for exact prob
dpois(15, 12)

