# Set working directory
setwd("C:\\Users\\it24102279\\Desktop\\IT24102279")

# Read data
data <- read.table("data.txt", header = TRUE)
attach(data)

# Assume the column name is 'Weight'
weights <- Weight

# 1. Population mean and sd
pop_mean <- mean(weights)
pop_sd <- sd(weights)

print("Population Mean")
print(pop_mean)
print("Population Standard Deviation")
print(pop_sd)

# 2. Draw 25 random samples of size 6
n_samples <- 25
sample_size <- 6
sample_means <- numeric(n_samples)
sample_sds <- numeric(n_samples)

for (i in 1:n_samples) {
  samp <- sample(weights, sample_size, replace = TRUE)
  sample_means[i] <- mean(samp)
  sample_sds[i] <- sd(samp)
}

# Print sample means and sds
print("Sample Means and Standard Deviations")
for (i in 1:n_samples) {
  print("Sample Number")
  print(i)
  print("Mean")
  print(sample_means[i])
  print("Standard Deviation")
  print(sample_sds[i])
}

# 3. Mean and sd of sample means
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

print("Mean of Sample Means")
print(mean_of_sample_means)
print("Standard Deviation of Sample Means")
print(sd_of_sample_means)

# Relationship explanation
print("Relationship")
print("The mean of the sample means is approximately equal to the population mean")
print(pop_mean)
print("The standard deviation of the sample means is approximately equal to the population sd divided by sqrt(sample size)")
print(pop_sd / sqrt(sample_size))
